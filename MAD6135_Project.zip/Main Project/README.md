# Shopping web site - cart item using javascipt

- ADD ITEMS TO CART - JAVASCRIPT PROJECT

- Function that add item to the cart is coded in js/app.js
